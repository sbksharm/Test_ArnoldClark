﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PaymentScheduleCalculator.LoanEntities;

namespace PaymentScheduleCalculator
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCalculate_Click(object sender, EventArgs e)
        {
            LoanEntity newLoan = new LoanEntity();
            newLoan.AgreementValue = Convert.ToDouble(txtArrangementFee.Text);
            newLoan.CompletionValue = Convert.ToDouble(txtCompletionFee.Text);
            newLoan.Amount = Convert.ToDouble(txtLoanAmount.Text);
            newLoan.Tenure = Convert.ToInt16(ddlTenure.SelectedValue);
            newLoan.Deposit = Convert.ToDouble(txtDeposit.Text);

            List<PaymentSchedule> payments = new List<PaymentSchedule>();
            payments = PaymentCalculate.EMICalc(newLoan);

            grdPaymetSchedule.DataSource = payments;
            grdPaymetSchedule.DataBind();
            
        }
    }
}