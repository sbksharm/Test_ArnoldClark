﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PaymentScheduleCalculator.LoanEntities
{
    public class LoanEntity
    {
        public double Amount { get; set; }
        public double Deposit { get; set; }
        public int Tenure { get; set; }
        public double AgreementValue { get; set; }
        public double CompletionValue { get; set; }
    }
}