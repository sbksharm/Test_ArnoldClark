﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PaymentScheduleCalculator.LoanEntities
{
    public class PaymentSchedule
    {
        public DateTime Date { get; set; }
        public double EMIAmount { get; set; }
    }    
}