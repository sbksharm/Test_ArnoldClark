﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PaymentScheduleCalculator.LoanEntities
{
    public class PaymentCalculate
    {
        public static List<PaymentSchedule> EMICalc(LoanEntity loanData)
        {
            int financeMonths = loanData.Tenure * 12;
            int currentMonth = DateTime.Now.Month;
            int currentYear = DateTime.Now.Year;
            double balanceAmount = loanData.Amount - loanData.Deposit;
            double monthlyEMI = balanceAmount / financeMonths;

            List<PaymentSchedule> paySchedule = new List<PaymentSchedule>();
            PaymentSchedule emiDetail;

            for (int i = 0; i < financeMonths; ++i)
            {
                emiDetail = new PaymentSchedule();
               
                DateTime dt = DateTime.Now.AddMonths(i);

                dt = new DateTime(dt.Year, dt.Month, 1);

                while (dt.DayOfWeek != DayOfWeek.Monday)
                {
                    dt = dt.AddDays(1);
                }

                emiDetail.Date = dt;

                if (i == 0)
                {
                    emiDetail.EMIAmount = monthlyEMI + loanData.AgreementValue;
                }
                else if (i == financeMonths - 1)
                {
                    emiDetail.EMIAmount = monthlyEMI + loanData.CompletionValue;
                }
                else
                {
                    emiDetail.EMIAmount = monthlyEMI;
                }

                paySchedule.Add(emiDetail);
            }

            return paySchedule.OrderBy(n => n.Date).ToList();
        }
    }

}