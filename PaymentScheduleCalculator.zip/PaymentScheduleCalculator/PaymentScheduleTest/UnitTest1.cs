﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PaymentScheduleCalculator.LoanEntities;
using System.Collections.Generic;

namespace PaymentScheduleTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            LoanEntity newLoan = new LoanEntity();
            newLoan.AgreementValue = Convert.ToDouble(80);
            newLoan.CompletionValue = Convert.ToDouble(20);
            newLoan.Amount = Convert.ToDouble(50);
            newLoan.Tenure = Convert.ToInt16(1);
            newLoan.Deposit = Convert.ToDouble(14);

            List<PaymentSchedule> paymentsActual = new List<PaymentSchedule>();
            List<PaymentSchedule> paymentsExpected = new List<PaymentSchedule>();
            paymentsActual = PaymentCalculate.EMICalc(newLoan);

            PaymentSchedule emi1 = new PaymentSchedule();
            emi1.Date = 

            paymentsExpected = new List<PaymentSchedule> { new PaymentSchedule(), new PaymentSchedule() };
        }
    }
}
